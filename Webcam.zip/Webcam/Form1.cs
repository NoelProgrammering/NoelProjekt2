﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AForge.Video;
using AForge.Video.DirectShow;
using System.Data.SqlClient;

namespace Webcam
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }



        FilterInfoCollection filterInfoCollection;
        VideoCaptureDevice videoCaptureDevice;
        Bitmap bitmap;


        private void Label1_Click(object sender, EventArgs e)


        {

            filterInfoCollection = new FilterInfoCollection(FilterCategory.VideoInputDevice);
            foreach (FilterInfo filterInfo in filterInfoCollection)
                cboCamera.Items.Add(filterInfo.Name);
            cboCamera.SelectedIndex = 0;
            videoCaptureDevice = new VideoCaptureDevice();
        }


        private void CboCamera_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void VideoCaptureDevice_NewFrame(object sender, AForge.Video.NewFrameEventArgs eventArgs)
        {
            bitmap = (Bitmap)eventArgs.Frame.Clone();
            pic.Image = bitmap;
            SavePicture();
        }
        private void SavePicture()
        {
            Bitmap current = (Bitmap)bitmap.Clone();
            string filepath = @"C:\Users\noel.lindell\Pictures\webcam";
            string fileName = Path.Combine(filepath, DateTime.Now.ToString("yyyyMMdd_hh_mm_ss") + ".png");
            current.Save(fileName);
            current.Dispose();
        }

        private void Pic_Click(object sender, EventArgs e)
        {

        }

        private void BtnStart_Click(object sender, EventArgs e)
        {
            pic.Visible = true;
            videoCaptureDevice = new VideoCaptureDevice(filterInfoCollection[cboCamera.SelectedIndex].MonikerString);
            videoCaptureDevice.NewFrame += VideoCaptureDevice_NewFrame;
            videoCaptureDevice.Start();
            label2.Visible = true;
            cboCamera.Visible = true;
            label1.Visible = true;
            btnStart.Enabled = false;

            string ConnectionString;
            SqlConnection con;
            ConnectionString = @"Data Source=CND8263QR4\MSSQLSERVERXD;Initial Catalog=NoelDB;Integrated Security=True";
            con = new SqlConnection(ConnectionString);
            con.Open();

            SqlCommand command;
            SqlDataReader dataReader;
            string sql;
            sql = "SELECT Tests FROM DBNoel";

            command = new SqlCommand(sql, con);
            dataReader = command.ExecuteReader();
            dataReader.Read();
            btnStart.Text = dataReader["Tests"].ToString();
            con.Close();
        }

        

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (videoCaptureDevice.IsRunning == true)
                videoCaptureDevice.Stop();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            filterInfoCollection = new FilterInfoCollection(FilterCategory.VideoInputDevice);
            foreach (FilterInfo Device in filterInfoCollection)
                cboCamera.Items.Add(Device.Name);
            cboCamera.SelectedIndex = 0;
            videoCaptureDevice = new VideoCaptureDevice();


        }

        private void Label2_Click(object sender, EventArgs e)
        {
            
        }

        private void PictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
